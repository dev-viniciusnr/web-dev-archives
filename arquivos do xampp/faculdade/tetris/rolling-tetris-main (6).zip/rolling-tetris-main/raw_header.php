<header>
    <div class="header">
        <div class="title">
            <h2>Rolling Tetris</h2>
        </div>
    </div>
</header>