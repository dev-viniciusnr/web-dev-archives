<footer>
    <div class="footer">
        <div class="coluna">
            <div class="title">
                <h2>Rolling Tetris</h2>
            </div>
        </div>
        <div class="coluna">
            <div class="menu">
                <ul type="none">
                    <li><a href="menu.html">Início</a></li>
                    <li><a href="jogo.html">Tetris</a></li>
                    <li><a href="ranking_global.html">Ranking Global</a></li>
                </ul>
            </div>
        </div>
        <div class="coluna">
            <div class="livre">
                <div class="menu">
                    <ul type="none">
                        <li><a href="#">Minha Conta</a></li>
                        <li><a href="historico.html">Hístorico de Partidas</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="coluna">
            <div class="alunos">
                <ul type="none">
                    <li>Arthur Rodrigues - 213315</li>
                    <li>Igor Martins - 217972</li>
                    <li>Victor Pereira - 206588</li>
                    <li>Vinícius Nonato - 245394</li>
                </ul>
            </div>
        </div>
    </div>
</footer>