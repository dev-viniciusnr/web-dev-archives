<header>
    <div class="header">
        <div class="title">
            <h2>Rolling Tetris</h2>
        </div>
        <div class="menu">
            <nav>
                <ul>
                    <li><a href="menu.php">Ínicio</a></li>
                    <li><a href="jogo.php">Tetris</a></li>
                    <li><a href="ranking_global.php">Ranking Global</a></li>
                    <li><a href="historico.php">Hístorico de Partidas</a></li>
                </ul>
            </nav>
        </div>
    </div>
</header>