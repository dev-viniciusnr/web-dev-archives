<header>
    <div class="header">
        <a href="menu.php">
            <div class="title">
                <h2>Rolling Tetris</h2>
            </div>
        </a>
        <div class="menu">
            <nav>
                <ul>
                    <li><a href="jogo.php">Tetris</a></li>
                    <li><a href="ranking_global.php">Ranking Global</a></li>
                    <li><a href="historico.php">Hístorico de Partidas</a></li>
                    <li><a href="perfil.php">Minha Conta</a></li>
                    <li><a href="deslogar.php">Sair</a></li>
                </ul>
            </nav>
        </div>
    </div>
</header>