<header>
    <div class="header">
        <a href="index.php">
        	<div class="title">
            	<h2>Rolling Tetris</h2>
        	</div>
        </a>
    </div>
</header>