<!DOCTYPE html>
<html>
<head>
	<title>Usuário cadastrado</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<?php require_once('header.php'); ?>

	<div class="container">
		<h1>Usuario Cadastrado com Sucesso</h1>
		<a href="alunos.php"><button>Ver Alunos Cadastrados</button></a>
		<a href="index.php"><button>Cadastrar Mais Alunos</button></a>
	</div>
</body>
</html>