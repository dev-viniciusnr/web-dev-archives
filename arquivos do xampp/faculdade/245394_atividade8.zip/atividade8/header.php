<nav class="header">
	<ul>
		<a href="index.php"><li>Cadastrar Aluno</li></a>
		<a href="alunos.php"><li>Alunos Cadastrados</li></a>
	</ul>
</nav>